-- Script to add tier pricing for a product
-- CustomerRoleId = 1 (e.g., Registered), ProductId = 101, Quantity = 10, Price = 200

INSERT INTO [DB_5848_althornew470].[dbo].[TierPrice] 
([CustomerRoleId], [ProductId], [StoreId], [Quantity], [Price], [StartDateTimeUtc], [EndDateTimeUtc])
VALUES
(1, 101, 1, 10, 200.00, GETDATE(), DATEADD(DAY, 30, GETDATE()));
