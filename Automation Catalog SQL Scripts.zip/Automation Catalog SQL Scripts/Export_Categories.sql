-- Script to export categories data in XML format

SELECT *
FROM [dbo].[Category]
FOR XML PATH('row'), ROOT('categories');
