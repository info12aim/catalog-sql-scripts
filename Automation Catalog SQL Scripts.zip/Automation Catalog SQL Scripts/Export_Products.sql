-- Script to export products data in XML format

SELECT *
FROM [dbo].[Product]
FOR XML PATH('row'), ROOT('products');
