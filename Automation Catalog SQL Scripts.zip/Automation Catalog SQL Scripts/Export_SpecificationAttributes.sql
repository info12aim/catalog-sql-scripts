-- Script to export product specification attributes

SELECT *
FROM [dbo].[ProductSpecificationAttribute]
FOR XML PATH('row'), ROOT('specificationattributes');
