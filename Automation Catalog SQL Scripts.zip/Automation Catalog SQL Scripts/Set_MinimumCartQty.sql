-- Script to set minimum cart quantity for a product

UPDATE [dbo].[Product]
SET OrderMinimumQuantity = 5
WHERE Id = 101;
