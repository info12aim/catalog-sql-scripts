-- Script to disable shipping for a product
UPDATE [dbo].[Product]
SET IsShipEnabled = 0
WHERE Id = 101;

-- Script to enable shipping for a product
UPDATE [dbo].[Product]
SET IsShipEnabled = 1
WHERE Id = 101;
