-- Script to update product prices from Excel by fixed value
-- Assumes TempProductPriceUpdates table contains ProductId, NewPrice

UPDATE p
SET p.Price = t.NewPrice
FROM [DB_5848_althornew470].[dbo].[Product] p
INNER JOIN [DB_5848_althornew470].[dbo].[TempProductPriceUpdates] t ON p.Id = t.ProductId;
