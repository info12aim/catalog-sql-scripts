-- Script to increase product prices by percentage using Excel data
-- Assumes TempProductPriceUpdates table contains ProductId, PricePercentage

UPDATE p
SET p.Price = p.Price * (1 + (t.PricePercentage / 100))
FROM [dbo].[Product] p
INNER JOIN TempProductPriceUpdates t ON p.Id = t.ProductId;
